# SCRIPT DE ORDEM DE SERVIÇO

Criei esse script utilizando Html, CSS e Javascript.
A motivação para a criação do script, veio da necessidade de otimizar a criação de ordens de serviços no setor do Service Desk, onde é necessário haver uma padronização e otimização das "OS". Com esse script, espero poupar tempo e o esforço de ter que digitar todos os campos manualmente.

A versão atual está funcional e ainda necessita de alguns ajustes no CSS, que irei implementar nas futuras atualizações.
